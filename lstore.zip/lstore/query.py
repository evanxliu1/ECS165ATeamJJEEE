from lstore.table import Record
from lstore.config import *
from time import time


class Query:
    def __init__(self, table):
        self.table = table

    def _locate(self, col, val):
        idx = self.table.index.indices[col]
        if idx is not None:
            return self.table.index.locate(col, val)
        out = []
        for rid, loc in self.table.page_directory.items():
            (_, tail, _, _) = loc
            if tail:
                continue
            vals = self._get_record_values(rid)
            if vals[col] == val:
                out.append(rid)
        return out

    def _locate_range(self, lo, hi, col):
        idx = self.table.index.indices[col]
        if idx is not None:
            return self.table.index.locate_range(lo, hi, col)
        out = []
        for rid, loc in self.table.page_directory.items():
            _, tail, _, _ = loc
            if tail:
                continue
            vals = self._get_record_values(rid)
            if lo <= vals[col] <= hi:
                out.append(rid)
        return out

    def _get_record_values(self, base_rid, version=0):
        loc = self.table.page_directory[base_rid]
        ri, _, pg, slot = loc
        pr = self.table.page_ranges[ri]
        indir = pr.get_base_val(pg, slot, INDIRECTION_COLUMN)
        if indir == NULL_RID:
            vals = []
            for i in range(self.table.num_columns):
                vals.append(pr.get_base_val(pg, slot, NUM_META_COLS + i))
            return vals
        cur = indir
        n = abs(version)
        for _ in range(n):
            tloc = self.table.page_directory[cur]
            tri, _, tpg, tslot = tloc
            tpr = self.table.page_ranges[tri]
            prev = tpr.get_tail_val(tpg, tslot, INDIRECTION_COLUMN)
            if prev == NULL_RID:
                vals = []
                for i in range(self.table.num_columns):
                    vals.append(pr.get_base_val(pg, slot, NUM_META_COLS + i))
                return vals
            cur = prev
        tloc = self.table.page_directory[cur]
        tri, _, tpg, tslot = tloc
        tpr = self.table.page_ranges[tri]
        vals = []
        for i in range(self.table.num_columns):
            vals.append(tpr.get_tail_val(tpg, tslot, NUM_META_COLS + i))
        return vals

    def delete(self, pk):
        try:
            rids = self.table.index.locate(self.table.key, pk)
            if not rids:
                return False
            rid = rids[0]
            vals = self._get_record_values(rid)
            for i in range(self.table.num_columns):
                if self.table.index.indices[i] is not None:
                    self.table.index.delete_entry(i, vals[i], rid)
            if rid in self.table.page_directory:
                del self.table.page_directory[rid]
            return True
        except:
            return False

    def insert(self, *cols):
        try:
            if len(cols) != self.table.num_columns or None in cols:
                return False
            key_val = cols[self.table.key]
            if self.table.index.locate(self.table.key, key_val):
                return False
            rid = self.table.new_rid()
            ri, pr = self.table._current_range()
            row = [0] * self.table.total_cols
            row[INDIRECTION_COLUMN] = NULL_RID
            row[RID_COLUMN] = rid
            row[TIMESTAMP_COLUMN] = int(time())
            row[SCHEMA_ENCODING_COLUMN] = 0
            for i in range(self.table.num_columns):
                row[NUM_META_COLS + i] = cols[i]
            pg, slot = pr.add_base_record(row)
            self.table.page_directory[rid] = (ri, False, pg, slot)
            for i in range(self.table.num_columns):
                if self.table.index.indices[i] is not None:
                    self.table.index.insert_entry(i, cols[i], rid)
            return True
        except:
            return False

    def select(self, search_key, search_key_index, projected_columns_index):
        try:
            rids = self._locate(search_key_index, search_key)
            if not rids:
                return []
            res = []
            for rid in rids:
                if rid not in self.table.page_directory:
                    continue
                all_vals = self._get_record_values(rid)
                cols = []
                for i in range(self.table.num_columns):
                    if projected_columns_index[i] == 1:
                        cols.append(all_vals[i])
                    else:
                        cols.append(None)
                res.append(Record(rid, search_key, cols))
            return res
        except:
            return False

    def select_version(self, search_key, search_key_index, projected_columns_index, relative_version):
        try:
            rids = self._locate(search_key_index, search_key)
            if not rids:
                return []
            res = []
            for rid in rids:
                if rid not in self.table.page_directory:
                    continue
                all_vals = self._get_record_values(rid, relative_version)
                cols = []
                for i in range(self.table.num_columns):
                    if projected_columns_index[i] == 1:
                        cols.append(all_vals[i])
                    else:
                        cols.append(None)
                res.append(Record(rid, search_key, cols))
            return res
        except:
            return False

    def update(self, pk, *cols):
        try:
            rids = self.table.index.locate(self.table.key, pk)
            if not rids:
                return False
            base_rid = rids[0]
            if base_rid not in self.table.page_directory:
                return False
            ri, _, pg, slot = self.table.page_directory[base_rid]
            pr = self.table.page_ranges[ri]
            if cols[self.table.key] is not None:
                new_pk = cols[self.table.key]
                if new_pk != pk and self.table.index.locate(self.table.key, new_pk):
                    return False
            old_indir = pr.get_base_val(pg, slot, INDIRECTION_COLUMN)
            cur_vals = self._get_record_values(base_rid)
            new_vals = list(cur_vals)
            schema = 0
            for i in range(self.table.num_columns):
                if cols[i] is not None:
                    new_vals[i] = cols[i]
                    schema = schema | (1 << i)
            tail_rid = self.table.new_rid()
            tail_row = [0] * self.table.total_cols
            tail_row[INDIRECTION_COLUMN] = old_indir
            tail_row[RID_COLUMN] = tail_rid
            tail_row[TIMESTAMP_COLUMN] = int(time())
            tail_row[SCHEMA_ENCODING_COLUMN] = schema
            for i in range(self.table.num_columns):
                tail_row[NUM_META_COLS + i] = new_vals[i]
            tpg, tslot = pr.add_tail_record(tail_row)
            self.table.page_directory[tail_rid] = (ri, True, tpg, tslot)
            pr.set_base_val(pg, slot, INDIRECTION_COLUMN, tail_rid)
            old_schema = pr.get_base_val(pg, slot, SCHEMA_ENCODING_COLUMN)
            pr.set_base_val(pg, slot, SCHEMA_ENCODING_COLUMN, old_schema | schema)
            for i in range(self.table.num_columns):
                if cols[i] is not None and self.table.index.indices[i] is not None and cur_vals[i] != new_vals[i]:
                    self.table.index.update_entry(i, cur_vals[i], new_vals[i], base_rid)
            self.table.maybe_trigger_merge(ri)
            return True
        except:
            return False

    def sum(self, start_range, end_range, aggregate_column_index):
        try:
            rids = self._locate_range(start_range, end_range, self.table.key)
            if not rids:
                return False
            tot = 0
            for rid in rids:
                if rid not in self.table.page_directory:
                    continue
                tot = tot + self._get_record_values(rid)[aggregate_column_index]
            return tot
        except:
            return False

    def sum_version(self, start_range, end_range, aggregate_column_index, relative_version):
        try:
            rids = self._locate_range(start_range, end_range, self.table.key)
            if not rids:
                return False
            tot = 0
            for rid in rids:
                if rid not in self.table.page_directory:
                    continue
                tot = tot + self._get_record_values(rid, relative_version)[aggregate_column_index]
            return tot
        except:
            return False

    def increment(self, key, column):
        r = self.select(key, self.table.key, [1] * self.table.num_columns)[0]
        if r is False:
            return False
        up = [None] * self.table.num_columns
        up[column] = r[column] + 1
        return self.update(key, *up)
