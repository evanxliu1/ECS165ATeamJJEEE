import os
from collections import OrderedDict
from lstore.page import Page, write_page_to_disk, read_page_from_disk
from lstore.config import BUFFERPOOL_CAPACITY

# manages page caching so we dont have to hit disk every time
# uses LRU ordered dict, evicts old pages when full
# dirty pages get writen back before eviction
class BufferPool:
    def __init__(self, capacity=BUFFERPOOL_CAPACITY):
        self.capacity = capacity
        self.db_path = None
        self.pages = OrderedDict()    # pid -> Page
        self.dirty = set()
        self.pin_counts = {}
        self._made_dirs = set()

    # builds filepath for a page from its id tuple
    def _page_filepath(self, page_id):
        a, b, tail, p, c = page_id
        seg = 'tail' if tail else 'base'
        return os.path.join(self.db_path, a, 'page_range_%d' % b, '%s_%d_%d.page' % (seg, p, c))

    # grab page from cache or load from disk, pin it
    def get_page(self, pid):
        if pid in self.pages:
            self.pages.move_to_end(pid)
            cnt = self.pin_counts.get(pid, 0)
            cnt = cnt + 1
            self.pin_counts[pid] = cnt
            return self.pages[pid]

        p = self._load_from_disk(pid)
        if p is None:
            p = Page()

        while len(self.pages) >= self.capacity:
            self._evict()

        self.pages[pid] = p
        self.pages.move_to_end(pid)
        cnt = self.pin_counts.get(pid, 0) + 1
        self.pin_counts[pid] = cnt
        return p

    # fast path for reads - if already cached we skip pinning
    def read_value(self, pid, slot):
        page = self.pages.get(pid)
        if page is not None:
            return page.read(slot)
        page = self.get_page(pid)
        val = page.read(slot)
        self.unpin(pid)
        return val

    def mark_dirty(self, pid):
        self.dirty.add(pid)

    def unpin(self, pid):
        if pid not in self.pin_counts:
            return
        c = self.pin_counts[pid] - 1
        self.pin_counts[pid] = c
        if c <= 0:
            del self.pin_counts[pid]

    def flush_all(self):
        to_flush = [x for x in self.dirty]
        for pid in to_flush:
            self._flush_page(pid)
        self.dirty.clear()

    # kick out least recently used unpinned page
    def _evict(self):
        for pid in self.pages:
            if pid not in self.pin_counts:
                if pid in self.dirty:
                    self._flush_page(pid)
                    self.dirty.discard(pid)
                del self.pages[pid]
                return
        # everything pinned, just bump capacity
        self.capacity = self.capacity + 1

    def _load_from_disk(self, pid):
        if self.db_path is None:
            return None
        path = self._page_filepath(pid)
        try:
            return read_page_from_disk(path)
        except FileNotFoundError:
            return None

    def _flush_page(self, pid):
        if self.db_path is None or pid not in self.pages:
            return None
        path = self._page_filepath(pid)
        d = os.path.dirname(path)
        if d not in self._made_dirs:
            os.makedirs(d, exist_ok=True)
            self._made_dirs.add(d)
        write_page_to_disk(self.pages[pid], path)
