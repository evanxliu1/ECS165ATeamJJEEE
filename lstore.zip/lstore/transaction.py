from lstore.table import Table, Record
from lstore.index import Index

class Transaction:
    def __init__(self):
        self.queries = []
        pass

    # add a query to this transaction
    def add_query(self, query, table, *args):
        self.queries.append((query, args))

    # returns True if commit, False on abort
    def run(self):
        for query, args in self.queries:
            result = query(*args)
            if result == False:
                return self.abort()
        return self.commit()

    def abort(self):
        # TODO: roll-back and whatever else
        return False

    def commit(self):
        # TODO: commit to db
        return True
